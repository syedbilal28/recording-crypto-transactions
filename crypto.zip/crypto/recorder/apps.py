from django.apps import AppConfig


class RecorderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'recorder'
